﻿using ControlCantina;
using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmCantina
{
    public partial class Form1 : Form
    {
        Barra barra;
        Cantina cantina;
        public Form1()
        {
            InitializeComponent();
            barra = new Barra();
            this.barra.SetCantina = Cantina.GetCantina(10);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbTipo.DataSource = Enum.GetValues(typeof(Botella.Tipo));
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Botella.Tipo tipo;
            Enum.TryParse<Botella.Tipo>(cmbTipo.SelectedValue.ToString(), out tipo);
            if (txtMarca.Text != "" && nudContenido.Value >=1 && nudCapacidad.Value <=1500)
            {
                if (rbtnAgua.Checked == true)
                {
                    Botella botella = new Agua((int)nudCapacidad.Value,txtMarca.Text,(int)nudContenido.Value);
                }
                else
                {
                    if (rbtnCerveza.Checked == true)
                    {
                        Botella botella = new Cerveza((int)nudCapacidad.Value, txtMarca.Text, (int)nudContenido.Value);
                        
                    }
                }
            }
        }
    }
}
