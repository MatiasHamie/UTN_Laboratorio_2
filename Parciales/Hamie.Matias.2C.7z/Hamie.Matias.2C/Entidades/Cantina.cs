﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cantina
    {
        #region Campos
        private List<Botella> botellas;
        private int espaciosTotales;
        private  static Cantina singleton;
        #endregion

        #region Propiedades
        public List<Botella> Botellas
        {
            get { return this.botellas; }
        }
        #endregion

        #region Constructores
        private Cantina(int espacios)
        {
            botellas = new List<Botella>();
            this.espaciosTotales = espacios;
        }
        #endregion

        #region Métodos
        public static Cantina GetCantina(int espacios)
        {
           
            if(Cantina.singleton is null)
            {
                Cantina.singleton = new Cantina(espacios);
                return singleton;
            }
            else
            {
                Cantina.singleton.espaciosTotales = espacios;
                return singleton;
            }
        }
        #endregion

        #region Sobrecarga de Operadores
        public static bool operator +(Cantina c,Botella b)
        {
            if(c.espaciosTotales > 1)
            {
                foreach (Botella botella in c.botellas)
                {
                    if (!(c.botellas.Contains(b)))
                    {
                        c.botellas.Add(b);
                        return true;
                    }
                }
            }

            return false;
        }
        #endregion

    }
}
