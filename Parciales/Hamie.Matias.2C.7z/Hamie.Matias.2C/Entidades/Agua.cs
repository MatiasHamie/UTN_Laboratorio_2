﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Agua:Botella
    {
        #region Campos
        private const int MEDIDA = 400;
        #endregion

        #region Constructores
        public Agua(int capacidadML, string marca, int contenidoML) : base(marca, capacidadML, contenidoML)
        {
            
        }
        #endregion

        #region Métodos
        protected string GenerarInforme()
        {
            //StringBuilder cadena = new StringBuilder(base.ToString());

            //cadena.AppendFormat($"");

            return base.ToString();
        }
        #endregion

        #region Sobrecarga de Métodos
        public override int ServirMedida()
        {
            if (MEDIDA <= base.contenidoML)
            {
                return base.contenidoML - MEDIDA;
            }
            else
            {
                return base.contenidoML;
            }
        }

        public int ServirMedida(int medida)
        {
            if (medida > base.contenidoML)
            {
                return this.ServirMedida();
            }
            else
            {
                return base.contenidoML - medida;
            }
        }
        #endregion
    }
}
