﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cerveza:Botella
    {
        #region Constantes
        private const int MEDIDA = 330;
        #endregion

        #region Campos
        private Tipo tipo;
        #endregion

        #region Constructores
        public Cerveza(int capacidadML, string marca, int contenidoML):this(capacidadML, marca,Botella.Tipo.Vidrio, contenidoML)
        {
            
        }

        public Cerveza(int capacidadML, string marca,Tipo tipo, int contenidoML):base(marca,capacidadML,contenidoML)
        {
           
        }
        #endregion

        #region Métodos
        protected override string GenerarInforme()
        {
            StringBuilder cadena = new StringBuilder(base.ToString());

            cadena.AppendFormat($"Medida Cerveza: {MEDIDA} - Tipo: {this.tipo}");

            return cadena.ToString();
        }

        public override int ServirMedida()
        {
            return base.contenidoML - ((MEDIDA * 80)/100);
        }
        #endregion

        #region Conversion Implicita
        public static implicit operator Botella.Tipo(Cerveza cerveza)
        {
            return cerveza.tipo;
        }
        #endregion
    }
}
